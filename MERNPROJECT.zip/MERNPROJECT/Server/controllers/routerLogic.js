
import UserDetail from '../model/userSchema.js';
import UserPost from '../model/postsSchema.js';

export const login = async (req,res) => {
  try {
    if(!req.body.email || !req.body.password)
    {
      res.json({error:"Please Fill All Field"})
    }
    const loginUser = await UserDetail.findOne({ email: req.body.email})
    console.log(!!loginUser);
    if(!!loginUser)
    {
      if(loginUser.password == req.body.password)
      {
        console.log("Inside If");
        const loginUserPosts = await UserPost.find({email:req.body.email});
  console.log(loginUser.email)

    res.status(200).json({message:"Login Successfully",loginUser,loginUserPosts});
    console.log(loginUserPosts[1])
  }
  else {
    res.json({error:"Invalid Credentials"})
  }
  }
  else {
    res.json({error:"User does not exists"})
  }
  } catch (e) {
      res.send(e)
  }
 }

 export const register = async (req,res) => {
  const userData = new UserDetail({
    name :req.body.name,
    surname :req.body.surname,
    email : req.body.email,
    phonenumber :req.body.phonenumber,
    password :req.body.password,
    cpassword :req.body.cpassword,
  })
  try {
    console.log("Inside Try");
    if(!req.body.name || !req.body.surname || !req.body.email || !req.body.phonenumber || !req.body.password || !req.body.cpassword )
    { console.log("Inside If");
       res.json({error:"Please Fill All Fields"});
    }
    const a1 = await userData.save();
      res.status(200).json({message:"User Registered Successfully",a1})
  } catch (e) {
    res.send(e)
  }
 }

 export const savepost = async (req,res) =>
 {
   const userposts = new UserPost({
     email:req.body.email,
     date:req.body.selectedDate,
     post:req.body.post

   })
   try{
     console.log(req.body)

     if(!req.body.email || !req.body.selectedDate || !req.body.post)
     {
       res.json({error:"Please Fill All Fields"});
     }
     else {
       const post = await userposts.save();
       res.status(200).json({message:"Post Saved Successfully",post})
     }
   }
   catch(e)
   {
      res.send(e)
   }
 }

export const viewpost = async (req,res) =>
{
    const loginUserPosts = await UserPost.find({email:req.body.email});
    res.status(200).json({message:"User Posts",loginUserPosts})
}

export const updatedetail = ('/id',async(req,res) =>
{
try{
  const id = req.params.id;
const update =req.body;
console.log(id+" "+update)
const result = await UserDetail.findByIdAndUpdate(id,update, { new: true })
console.log(result)
res.status(200).json({message:"Data Updated",result})
}
catch(e)
{
res.send(e)
}
});
