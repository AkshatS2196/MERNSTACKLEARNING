import React from 'react';
import MaterialTable from 'material-table'
import { Drawer,Button,List,ListItem,ListItemIcon,ListItemText,TextField,IconButton} from '@material-ui/core';
import DeleteIcon from '@material-ui/icons/Delete';
import EditIcon from '@material-ui/icons/Edit';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import SearchIcon from '@material-ui/icons/Search';
import axios from 'axios';

class View_Post extends React.Component
{
  constructor() {
    super();

    this.state = {
      open: false,
      post:[]
    };
  }

  componentDidMount()
  {
     let currentComponent = this;
    let data = localStorage.getItem('Details');
    data = JSON.parse(data);
    if(data == null)
    {
      this.props.history.push('/');
    }
    else {

    console.log(data.email)
    axios.post('/viewpost',{email :data.email})
    .then(function (response) {
      console.log(response.data.loginUserPosts[0].date);
      currentComponent.setState({ post: response.data.loginUserPosts });
      console.log(currentComponent.state.post);
    })
    .catch(function (error) {
      console.log(error);
    });
  }
}
  render()
  {
    let _this = this;
    const post = [_this.state.post];
    console.log("Render"+ post[0])
    console.warn("Render"+ post[0])
    const column = [
      {
        title:"Date",
        field:"date"
      },
      {
        title:"Post",
        field:"post"
      }
    ]
  return(
<div className="App" >
<h2> Table </h2>
<MaterialTable title="Posts"
data={post[0]}
columns={column}
>
</MaterialTable>

</div>


  )
}
}

export default View_Post
