import React from 'react';
import { Link } from 'react-router-dom';
import { Drawer,Button,List,ListItem,ListItemIcon,ListItemText,TextField,IconButton} from '@material-ui/core';
import PostAddIcon from '@material-ui/icons/PostAdd';
import AccountCircleIcon from '@material-ui/icons/AccountCircle';
import ViewListIcon from '@material-ui/icons/ViewList';
import ExitToAppIcon from '@material-ui/icons/ExitToApp';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import Grid from '@material-ui/core/Grid';
import logo from './MERN.jpg';
export default class Home extends React.Component
{
  constructor() {
    super();

    this.state = {
      open: false,
      name:'',
      surname:''

    };
    // this.handleOpen = this.handleOpen.bind(this);
    //   this.handleClose = this.handleClose.bind(this);

  }
  // handleOpen() {
  //   this.setState({
  //   open: true,
  // });
  // console.log("Hii")
  // }
  // handleClose = () => {
  //   console.log(this.state.open)
  //
  // this.setState({
  // open: false,
  // });
  //   console.log(this.state.open)
  // }
  //
  // openModal = () =>
  // {
  //   alert("Hii")
  // }
  //
  // submit = () =>
  // {
  //   alert("Hii");
  //   this.handleClose();
  // }
componentDidMount()
{
  let data = localStorage.getItem('Details');
  data = JSON.parse(data);
    console.log("OUTTTTTTTTTt");
  if(data == null)
  {
    console.log("IFFFFFFFFFFF");
    this.props.history.push('/');
  }
  else {
  const name = data.name
  const surname = data.surname

  console.log(name +" "+surname);

  this.setState({name:name })
  this.setState({surname:surname })
console.log("After setting State"+ this.state.name +" "+this.state.surname);
}
}

logout = () =>
{
localStorage.clear();
 this.props.history.push('/');
}
  render()
  {
  return(
<div   style ={{display:'flex'}}>
<Drawer style ={{width:'300px'}}
anchor="left"
open="true"
variant="persistent">
<List>

<Link to="/createpost">
<ListItem button>
<ListItemIcon>
<IconButton>
<PostAddIcon />
</IconButton>
</ListItemIcon>

<ListItemText primary={"Create Post"}/>
</ListItem>
</Link>


<Link to="/viewpost">
<ListItem button>
<ListItemIcon>
<ViewListIcon />
</ListItemIcon>
<ListItemText primary={"View Post"}/>
</ListItem>
</Link>


<Link to="/about">
<ListItem button>
<ListItemIcon>
<AccountCircleIcon />
</ListItemIcon>
<ListItemText primary={"User Info"}/>
</ListItem>
</Link>


<ListItem button onClick ={this.logout}>
<ListItemIcon >
<ExitToAppIcon />
</ListItemIcon>
<ListItemText primary={"Logout"}/>
</ListItem>


</List>
</Drawer>
<div style={{textAlign:'center'}}>
<Grid>
  <Grid item xs={12} lg={12}>
<h1> Welcome {this.state.name} {this.state.surname} </h1>
<img src={logo} />
</Grid>
</Grid>
</div>
</div>


  )
}
}
