import React, { Component } from 'react'
import { TextField,Button } from '@material-ui/core';
import {Formik} from 'formik';
import { Link } from 'react-router-dom'
import axios from 'axios';
import { browserHistory } from "react-router-dom";
class Login extends Component {
constructor(props)
{
  super(props);

}

   render() {
      return (
        <div>
        <Formik
           initialValues={{
             email: '',
             password: '',
           }}

           onSubmit={(values) => {
              var _this = this;
            console.log(values);
            axios.post('/login', values)
  .then(function (response) {
    console.log(response);
    if(response.data.message == "Login Successfully")
    {
      alert(response.data.message);
       localStorage.setItem('Details', JSON.stringify(response.data.loginUser));
       let data = localStorage.getItem('Details');
       data = JSON.parse(data);
       console.warn(data)
       console.log("Data of Login User "+data.name + " "+data.phonenumber)
 _this.props.history.push('/home');
    }
    else {
      alert(response.data.error);
    
    }
  })
  .catch(function (error) {
    console.log(error);
  });
  // this.props.history.push('/home');

           }}>
           {({
             handleChange,
             handleBlur,
             handleSubmit,
             values,
             errors,
             touched,
             isValid,
             setFieldValue,
             setFieldTouched,
             submitCount,
           }) => (
         <div style ={divStyle}>
        <h1> Login Page </h1>
        <TextField
         name="email"
          label="Email ID"
          variant="filled"
          onChange={handleChange('email')}/>
          <br />
            <br />
            <TextField
             name="password"
              label="Password"
              type="Password"
              variant="filled"
              onChange={handleChange('password')}/>
              <br />
              <br />
        <Button
        variant="contained"
        color="primary"
       onClick={handleSubmit}
        >
          Login
        </Button>


         </div>
       )}
       </Formik>
       <div style={{marginLeft:"55%"}}>
       <Link to='/register'>New User? Signup</Link>
       </div>
         </div>
      )
   }
}
export default Login

const divStyle = {
  textAlign: 'center',
}
