import React from 'react';
import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import { MuiPickersUtilsProvider } from '@material-ui/pickers';
import DateFnsUtils from '@date-io/date-fns';
import { KeyboardDatePicker } from "@material-ui/pickers";
import {Formik} from 'formik';
import axios from 'axios';
 class Create_Post extends React.Component
{
  constructor() {
    
    let data = localStorage.getItem('Details');
    data = JSON.parse(data);
    console.warn("Email "+data.email);
    super();

    this.state = {
      selectedDate:null,
      post:'',
      email:data.email
    };
     // this.handleState = this.handleState.bind(this);
  }

// handleState = (e) =>
// {
//   this.setState({[e.target.name]:e.target.value})
// }
setDate = (date) =>
{ var formattedDate =
      ('0' + date.getDate()).slice(-2) +
      '/' +
      ('0' + (date.getMonth() + 1)).slice(-2) +
      '/' +
      date.getFullYear();
      console.log(formattedDate)
  this.setState({ selectedDate: date });
}

setPost = (userpost) =>
{ console.log(userpost)

  this.setState({ post: userpost });
}


 handleSubmit = () =>
 {
   console.log(this.state);
   console.log(this.state.selectedDate);
   console.log(this.state.post);

   axios.post('/savepost',this.state)
   .then(function (response) {
     console.log(response.data)
     if(response.data.message == "Post Saved Successfully")
     {
     alert(response.data.message);
   }
   else {
     alert(response.data.error);
   }
   })
   .catch(function (error) {
     console.log(error);
   });
 }
  render() {
    const {selectedDate,post} = this.state
     return (
        <div style={{textAlign:'center'}}>
      <h1> Create Post </h1>
      <MuiPickersUtilsProvider utils={DateFnsUtils}>
    <KeyboardDatePicker
       variant="filled"
       format="dd/mm/yyyy"
       name="date"
       margin="normal"
       id="date-picker-inline"
       label="Select Date"
        onChange={this.setDate}
       value={selectedDate}

         style={{width:'20%' }}

     />
</MuiPickersUtilsProvider>
<br />
<br />

<TextField
       value={post}
       label="Post"
       style={{width:'20%' }}
       onChange={(e) => {
         this.setPost(e.target.value);
       }}
     />
<br />
<br />
<br />
<br />
  <Button
  variant="contained"
  color="primary"
 onClick={this.handleSubmit}
  >
    Submit Post
  </Button>
<br />
<br />
        </div>
     )
  }
}
const divStyle = {
 textAlign: 'center',
}

export default Create_Post
