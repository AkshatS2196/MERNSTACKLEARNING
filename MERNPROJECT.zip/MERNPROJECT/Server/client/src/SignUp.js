import React, { Component } from 'react'
import { TextField,Button } from '@material-ui/core';
import {Formik} from 'formik';
import axios from 'axios';
class SignUp extends Component {

   render() {
      return (
         <div>
         <Formik
            initialValues={{
              name: '',
              surname: '',
                email: '',
                  phonenumber: '',
                    password: '',
                      cpassword: '',
            }}

            onSubmit={(values) => {
                var _this = this;
             console.log(values);
             axios.post('/register', values)
   .then(function (response) {
     console.log(response);
     if(response.data.message === "User Registered Successfully"){
     alert(response.data.message);
     _this.props.history.push('/');
   }
   else{
     alert(response.data.error);
     _this.props.history.push('/');
   }
   })
   .catch(function (error) {
     console.log(error);
   });

            }}>
            {({
              handleChange,
              handleBlur,
              handleSubmit,
              values,
              errors,
              touched,
              isValid,
              setFieldValue,
              setFieldTouched,
              submitCount,
            }) => (
              <div style = {divStyle}>
        <h1> Register Here!! </h1>
<TextField
 name="name"
  label="First Name"
  variant="filled"
  onChange={handleChange('name')}/>
  <br />
   <br />
  <TextField
   name="surname"
    label="SurName"
    variant="filled"
    onChange={handleChange('surname')}/>
    <br />
     <br />
    <TextField
     name="email"
      label="Email ID"
      variant="filled"
      onChange={handleChange('email')} />
      <br />
        <br />
      <TextField
       name="phonenumber"
        label="Phone Number"
        type="Number"
        variant="filled"
        onChange={handleChange('phonenumber')} />
        <br />
         <br />
        <TextField
         name="password"
          label="Password"
          type="Password"
          variant="filled"
          onChange={handleChange('password')} />
          <br />
           <br />
          <TextField
           name="cpassword"
            label="Confirm Password"
            type="Password"
            variant="filled"
            onChange={handleChange('cpassword')} />
           <br />
            <br />
           <Button
           variant="contained"
           color="primary"
          onClick={handleSubmit}
           >
             SignUp
           </Button>
           <br />
            <br />
              </div>
          )}

          </Formik>
         </div>
      )
   }
}
const divStyle = {
  textAlign: 'center',
}

export default SignUp
