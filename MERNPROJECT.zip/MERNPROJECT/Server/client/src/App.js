import React, { Component } from 'react';
import Login from './Login';
import SignUp from './SignUp';
import Home from './Home';
import Create_Post from './Create_Post';
import View_Post from './View_Post';
import About from './About';
import { BrowserRouter, Route, Switch } from 'react-router-dom';

class App extends Component {

   render() {
      return (
         <>
         <Switch>
                 <Route path="/" component={Login} exact />
                 <Route path="/register" component={SignUp} />
                 <Route path="/home" component={Home} />
                 <Route path="/createpost" component={Create_Post} />
                 <Route path="/about" component={About} />
                 <Route path="/viewpost" component={View_Post} />

             </Switch>
         </>
      )
   }
}
export default App
