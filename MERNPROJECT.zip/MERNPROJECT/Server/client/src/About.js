import React from 'react';
import Grid from '@material-ui/core/Grid';
import Paper from '@material-ui/core/Paper';
import DeleteIcon from '@material-ui/icons/Delete';
import {IconButton,TextField,Button} from '@material-ui/core';
import EditIcon from '@material-ui/icons/Edit';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import Modal from 'react-modal';
import axios from 'axios';
class About extends React.Component
{

  constructor() {
    let data = localStorage.getItem('Details');
    data = JSON.parse(data);
    console.warn("First "+data);
    console.warn("Data"+ data._id)
    super();

    this.state = {
      nameopen: false,
      surnameopen:false,
      emailopen:false,
      numberopen:false,
      id:data._id,
      name:data.name,
      surname:data.surname,
      // email:data.email,
phonenumber:data.phonenumber,
  email:data.email,
    };
    this.handleOpen = this.handleOpen.bind(this);
      this.handleClose = this.handleClose.bind(this);
  }
  handleValue = (e) =>
  {
    this.setState({[e.target.name]:e.target.value})
  }

  handleOpen() {
    this.setState({
    nameopen: true,
  });
}
  handleSurnameOpen = () => {
    this.setState({
    surnameopen: true,
  });
}
  handleEmailOpen = () => {
    this.setState({
    emailopen: true,
  });
}
  handlePhoneOpen = () => {
    this.setState({
    phonenumberopen: true,
  });
}
handleClose = () => {
  console.log(this.state.open)
  let data = localStorage.getItem('Details');
  data = JSON.parse(data);
this.setState({
nameopen: false,
surnameopen: false,
emailopen: false,
phonenumberopen: false,
name: data.name,
surname:data.surname,
email:data.email,
phonenumber:data.phonenumber
});
  console.log(this.state.open)
}

update = () =>
{

  console.log(this.state)

  const id = this.state.id

  console.log("ID "+id)

  if(this.state.name == ''||this.state.surname == ''||this.state.email == ''||this.state.phonenumber == '') //why cant use just name instead of this.state.name?
  {
    alert("Field Cannot Be Blank")
    return;
  }

  axios.patch('/updatedetail/'+id,this.state)
  .then(function (response) {
    if(response.data.message == "Data Updated")
   alert(response.data.message)
      localStorage.setItem('Details', JSON.stringify((response.data.result)));
      let data = localStorage.getItem('Details');
      data = JSON.parse(data);
      console.warn(data);
    console.log(data.name);
  })
  .catch(function (error) {
    console.log(error);
  });
  this.setState({
  nameopen: false,
  surnameopen: false,
  emailopen: false,
  phonenumberopen: false,
  });
}

  render()
  {
    const {name,surname,email,phonenumber} = this.state
  return(
<div>
<Grid>
  <Grid item xs={12} lg={12}>
  <h1 style={{textAlign: 'center'}}> User Details </h1>
  </Grid>
</Grid>
<Grid style={{paddingTop:'2%'}}>
<Grid container spacing={3} style={{textAlign: 'center',paddingLeft:'20%'}}>
        <Grid item xs={3} lg={3}>
          <h1 style={{paddingLeft:'4%'}}> Name </h1>
        </Grid>
        <Grid item xs={3} lg={3}>
          <h3 style={{paddingTop:'3%'}}> {this.state.name} </h3>
          </Grid>
          <Grid item xs={3} lg={3}>
          <IconButton style={{paddingTop:'8%'}} onClick={this.handleOpen}>
          <EditIcon />
          </IconButton>
          <Dialog open={this.state.nameopen} onClose={() => this.handleClose()} aria-labelledby="form-dialog-title">
                  <DialogTitle id="form-dialog-title">Update</DialogTitle>
                  <DialogContent>
                    <DialogContentText>
                      Please provide the Updated Information
                    </DialogContentText>
                    <input
                      label="Name"
                      name="name"
                      multiline ="true"
                      value={this.state.name}
                      onChange={this.handleValue}
                      fullWidth = "true"
                      />
          </DialogContent>
          <DialogActions>
                    <Button onClick={() => this.update()} color="primary">
                      Update
                    </Button>
                    <Button onClick={() => this.handleClose()} color="primary">
                      Cancel
                    </Button>
                  </DialogActions>
          </Dialog>
          </Grid>
        </Grid>
        <Grid container spacing={3} style={{textAlign: 'center',paddingLeft:'20%'}}>
        <Grid item xs={3} lg={3}>
          <h1 style={{paddingLeft:'4%'}}> SurName </h1>
        </Grid>
        <Grid item xs={3} lg={3}>
          <h3 style={{paddingTop:'3%'}}> {this.state.surname} </h3>
        </Grid>
        <Grid item xs={3} lg={3}>
        <IconButton style={{paddingTop:'8%'}} onClick={this.handleSurnameOpen}>
        <EditIcon />
        </IconButton>
        <Dialog open={this.state.surnameopen} onClose={() => this.handleClose()} aria-labelledby="form-dialog-title">
                <DialogTitle id="form-dialog-title">Update</DialogTitle>
                <DialogContent>
                  <DialogContentText>
                    Please provide the Updated Information
                  </DialogContentText>
                  <input
                  name="surname"
                    label="Surame"
                    multiline ="true"
                      onChange={this.handleValue}
                    value={this.state.surname}
                    fullWidth = "true"
                    />
        </DialogContent>
        <DialogActions>
                  <Button onClick={() => this.update()} color="primary">
                    Update
                  </Button>
                  <Button onClick={() => this.handleClose()} color="primary">
                    Cancel
                  </Button>
                </DialogActions>
        </Dialog>
        </Grid>
        </Grid>
        <Grid container spacing={3} style={{textAlign: 'center',paddingLeft:'20%'}}>
        <Grid item xs={3} lg={3}>
          <h1 style={{paddingLeft:'4%'}}> Email ID </h1>
        </Grid>
        <Grid item xs={3} lg={3}>
          <h3 style={{paddingTop:'3%'}}> {this.state.email} </h3>
        </Grid>

          </Grid>
          <Grid container spacing={3} style={{textAlign: 'center',paddingLeft:'20%'}}>
        <Grid item xs={3} lg={3}>
          <h1 style={{paddingLeft:'4%'}}> Mobile Number </h1>
        </Grid>
        <Grid item xs={3} lg={3}>
          <h3 style={{paddingTop:'3%'}}> {this.state.phonenumber} </h3>
        </Grid>
        <Grid item xs={3} lg={3}>
        <IconButton style={{paddingTop:'8%'}} onClick={this.handlePhoneOpen}>
        <EditIcon />
        </IconButton>
        <Dialog open={this.state.phonenumberopen} onClose={() => this.handleClose()} aria-labelledby="form-dialog-title">
                <DialogTitle id="form-dialog-title">Update</DialogTitle>
                <DialogContent>
                  <DialogContentText>
                    Please provide the Updated Information
                  </DialogContentText>
                  <input
                    label="Phone Number"
                    multiline ="true"
                    name="phonenumber"
                    type="Number"
                    onChange={this.handleValue}
                    value={this.state.phonenumber}
                    fullWidth = "true"
                    />
        </DialogContent>
        <DialogActions>
                  <Button onClick={() => this.update()} color="primary">
                    Update
                  </Button>
                  <Button onClick={() => this.handleClose()} color="primary">
                    Cancel
                  </Button>
                </DialogActions>
        </Dialog>
        </Grid>
</Grid>
</Grid>
</div>
  )
}
}

export default About
