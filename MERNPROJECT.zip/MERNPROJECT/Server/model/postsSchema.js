import mongoose from 'mongoose';

const postsSchema = new mongoose.Schema({

 email : {
   type:String,
   require:true
 },
  date: {
    type: Date,
    default:Date.now,
    require: true
  },
  post: {
    type: String,
    require: true
  },
})

const UserPost = mongoose.model('USER_POST',postsSchema);

export default UserPost;
