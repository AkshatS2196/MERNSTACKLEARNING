import express from 'express';
import bodyParser from 'body-parser';
import mongoose from 'mongoose';
import cors from 'cors';
import router from './routes/routers.js';
import dotenv from 'dotenv'
dotenv.config({path:'./config.env'})
const app = express();

app.use(express.json());
app.use('/',router);
app.use(cors());
const CONNECTION_URL = process.env.CONNECTION_URL;
const PORT = process.env.PORT||3000;;
mongoose.connect(CONNECTION_URL)
 .then(() => console.log("Connection Successful"))
 .catch((error) => console.log(error));


//  mongoose.set('useFindAndModify', false);
if(process.env.NODE_ENV == "production")
{
  app.use(express.static("client/build"))
}


app.listen(PORT, () => {
  console.log("Server Running");
})
