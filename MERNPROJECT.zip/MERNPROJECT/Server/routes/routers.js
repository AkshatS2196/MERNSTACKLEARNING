import express from 'express';
import {login} from '../controllers/routerLogic.js';
import {register} from '../controllers/routerLogic.js';
import {savepost} from '../controllers/routerLogic.js';
import {viewpost} from '../controllers/routerLogic.js';
import {updatedetail} from '../controllers/routerLogic.js';
const router = express.Router();

router.post('/login', login)

router.post('/register',register)

router.post('/savepost',savepost)

router.post('/viewpost',viewpost)

router.patch('/updatedetail/:id',updatedetail)

export default router; //exporting the method router (not file router.js)
